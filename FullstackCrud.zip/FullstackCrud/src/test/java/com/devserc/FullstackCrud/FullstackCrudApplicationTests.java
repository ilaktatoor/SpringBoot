package com.devserc.FullstackCrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FullstackCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
