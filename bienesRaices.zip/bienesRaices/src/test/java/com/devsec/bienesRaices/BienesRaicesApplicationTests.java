package com.devsec.bienesRaices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BienesRaicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
