package com.devsec.bienesRaices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BienesRaicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(BienesRaicesApplication.class, args);
	}

}
